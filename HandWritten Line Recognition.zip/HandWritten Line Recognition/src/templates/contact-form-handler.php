<?php
   $name = $_POST['name'];
   $visitor_email = $_POST['email'];
   $message = $_POST['message'];
   
   $email_form = 'shobanashobana197@gmail.com';
   
   $email_subject = "New form submission";
   
   $email_body =  "user Name: $name.\n".
					"User Email: $visitor_email.\n".
					    "User Message: $message.\n";
						
	$to = "padmapriya31398@gmail.com";
	
	$headers = "From: $email_form \r\n";
	
	$headers .= "Reply-To: $visitor_email \r\n";
	
	mail($to,$email,$email_body,$headers);
	
	header("location: index.html");
	

?>